<html>
<!-- FORMULARIOS **/ 
 Creamos un FORMULARIO con html -->
	<head>
<!-- 	cabecera -->
	</head>
	<body>
	<!-- Definición del formulario -->
	<h1> Base de datos alumnos </h1>
	<img src="irc.jpg" width="90" height="100">
	
	<h2> Todos los registros: </h2>
	<form action= "registros.php" method="post">
	Mostrar todos los registros: 
	<input type ="submit" value="Mostrar" />
	</form>
	
	<h2> Búsqueda de Información: </h2>
	
	<form action= "buscar_id.php" method="post">
	identificador:<input type="text" name="identificador" size="4" maxlength="4"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>

	<form action= "buscar_nombre.php" method="post">
	nombre:<input type="text" name="nombre" size="20" maxlength="20"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>

	<form action= "buscar_localidad.php" method="post">
	Localidad:<input type="text" name="localidad" size="20" maxlength="20"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>

	
	<h2> Inserción de Registros: </h2>
	<form action= "insertar_registros.php" method="post">
nombre:<input type="text" name="nombre" size="20" maxlength="20"/> 
localidad:<input type="text" name="nombre" size="20" maxlength="20"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>
	
	<h2> Eliminar registros: </h2>
	<form action= "eliminar_registros.php" method="post">
id:<input type="text" name="id" size="20" maxlength="20"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>
	
	<h2> Actualizar registros: </h2>
	<form action= "actualizar_registros.php" method="post">
id:<input type="text" name="id" size="20" maxlength="20"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>
	
	</body>
</html>
