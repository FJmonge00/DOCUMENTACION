<?php
$app = $_POST["app"];
$version = $_POST["version"];
$cliente = $_POST["cliente"];

include("conexion.php");

function consulta($conn,$query){
	$resultado = mysqli_query($conn,$query);
	return $resultado;
}

// $res = consulta($conn,"INSERT INTO servicios VALUES ('','$version','$cliente', 'current_timestamp()')");
$res = consulta($conn,"INSERT INTO `servicios` (`app`,`version`, `cliente`) VALUES ('$app','$version', '$cliente');");
var_dump($res);

mysqli_close($conn); //cierra la conexion

?>