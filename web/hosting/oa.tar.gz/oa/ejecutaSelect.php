<?php
/** ENUNVIADO **/
// En este ejercicio incluimos el fichero de conexion
// a continuacion creamos una funcion que ejecuta una query 'select'
// que devuelve todos los registros de una tabla
// por ultimo cerramos la conexion.

include("conexion.php");

function consulta($conn,$query){
	$resultado = mysqli_query($conn,$query);
	return $resultado;
}

$res = consulta($conn,"SELECT * FROM servicios");
//var_dump($res);

mysqli_close($conn); //cierra la conexion

?>