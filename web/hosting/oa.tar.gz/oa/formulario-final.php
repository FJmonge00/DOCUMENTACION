<html>
<!-- FORMULARIOS **/ 
 Creamos un FORMULARIO con html -->
	<head>
<!-- 	cabecera -->
	</head>
	<body>
	<!-- Definición del formulario -->
	<h1> Base de datos Dominios_Web </h1>
	<img src="irc.jpg" width="90" height="100">
	
	<h2> Todos los registros: </h2>
	<form action= "registros.php" method="post">
	Mostrar todos los registros:
	<input type ="submit" value="Mostrar" />
	</form>
	
	<h2> Búsqueda de Información: </h2>
	
	<form action= "buscar_id.php" method="post">
	id:<input type="text" name="identificador" size="4" maxlength="4"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>

	<form action= "buscar_nombre.php" method="post">
	Nombre del servicio:<input type="text" name="nombre" size="20" maxlength="20"/> 
	<input type ="submit" value="Buscar" />
	<input type="Reset" value="Limpiar">
	</form>
	
	<form action= "buscar_localidad.php" method="post">
	Introduzca la provincia: 
	<input type="text" name="localidad" size="20" maxlength="20" /> 
	<input type ="submit" value="buscar" />
	<input type="Reset" value="Limpiar">
	</form>
	
	<h2> Inserción de Registros: </h2>
	<form action= "insertar_registros.php" method="post">
	Aplicación: <input type="text" name="app" size="30" maxlength="80" /> 
	Cliente:<input type="text" name="cliente" size="20" maxlength="80" /> 
	<input type ="submit" value="Insertar" />
	<input type="Reset" value="Limpiar">
	</form>
	
	<h2> Eliminar registros: </h2>
	<form action= "eliminar_registros.php" method="post">
	id: <input type="text" name="identificador" size="4" maxlength="4" /> 
	<input type ="submit" value="Eliminar" />
	<input type="Reset" value="Limpiar">
	</form>
	
	<h2> Actualizar registros: </h2>
	<form action= "actualizar_registros.php" method="post">
	id: <input type="text" name="identificador" size="4" maxlength="4" /> 
	Nombre del servicio: <input type="text" name="nombre" size="20" maxlength="20" /> 
	Servidor padre:<input type="text" name="localidad" size="20" maxlength="20" /> 
	<input type ="submit" value="Insertar" />
	<input type="Reset" value="Limpiar">
	</form>
	<br>
	<br>
	<h1>________________________________________________________________________________________________</h1>
	<br>
	<br>
	<h2>Nuevo Servicio</h2>
	<form action= "insertar_registros.php" method="post">
		<!-- Lista de selección -->
		Selecciona la opción deseada:
		<br>
		<br>
		Cliente:<input type="text" name="cliente" size="20" maxlength="80" required> 
			<br>
			App:<select name="app">
				<!-- Opciones de la lista -->
				<option value="joomla">Joomla</option>
				<option value="wordpress">WordPress</option>
				<option value="prestashop">PrestaShop</option>
				<option value="mediawiki">MediaWiki</option>
				<option value="drupal">Drupal</option>
			</select>
			<br>
			Versión de App:<select name="version">
				<!-- Opciones de la lista -->
				<option value="joomla:3.9.25-apache">Joomla 3.9.25</option>
				<option value="wordpress:4.8-apache">WordPress 4.8</option>
				<option value="prestashop/prestashop:1.7.7.2-apache">PrestaShop 1.7.7.2</option>
				<option value="mediawiki:1.35.1">MediaWiki 1.35.1</option>
				<option value="drupal:9.1.6-php8.0-apache-buster">Druapal 9.1.6</option>
			</select>
			<br>
			<!-- Fecha:<input type="datetime-local"> -->
			<br>
			<input type="submit" value="Lanzar Servicios">
			<input type="Reset" value="Limpiar">
		</form>
	</body>
	
</html>
