<?php
/** ENUNCIADO **/
// En este ejercicio creamos una funcion para establecer la conexion
// con el servidor de la Base de Datos asi como tambien seleccionamos
// una Base de Datos. A continuacion comprobamos la conexion
// imprimiendo un mensaje de confirmacion.


function conexion(){
   if (!($conn=mysqli_connect("localhost","zeus","Coria21")))
   {
      echo "Error conectando con la base de datos.";
      exit();
   }
   if (!mysqli_select_db($conn,"hosting"))
   {
      echo "Error seleccionando la base de datos.";
      exit();
   }
   return $conn;
}

$conn=conexion();
//echo "Conexi�n con la base de datos conseguida.<br>";

?>