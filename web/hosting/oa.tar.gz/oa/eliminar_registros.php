<?php
$identificador = $_POST["identificador"];

include("conexion.php");

function consulta($conn,$query){
	$resultado = mysqli_query($conn,$query);
	return $resultado;
}

$res = consulta($conn,"DELETE FROM SERVICIO WHERE id='$identificador'");
var_dump($res);

mysqli_close($conn); //cierra la conexion

?>