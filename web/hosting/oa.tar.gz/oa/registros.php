<html>
<head>
</head>
<body>
<h2> Listado de la tabla datos </h2>
<table border="1">
	<tr>
		<td>Identificador</td>
		<td>Aplicacion</td>
		<td>Version</td>
		<td>Cliente</td>
		<td>Fecha</td>
	</tr>
	<?php
	include("ejecutaSelect.php");
	//En la variable $res está guardada el resultado de ejecutaSelect.php
	//$registros es la variable que recorre el buvle foreach
	//El bucle foreach trabaja con líneas enteras
	foreach($res as $registros){ ?>
	<tr>
		<td><?php echo $registros["id"]?></td>
		<td><?php echo $registros['app']?></td>
		<td><?php echo $registros['version']?></td>
		<td><?php echo $registros['cliente']?></td>
		<td><?php echo $registros['fecha']?></td>
	</tr>
	<?php }?>
</table>
</body>
</html>