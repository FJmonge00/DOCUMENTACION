<?php
/** ENUNCIADO **/
// En este ejercicio incluimos el fichero de conexion
// a continuacion creamos una funcion que ejecuta una query 'insert'
// que se pasa por parametro e inserta un registro en una tabla
// por ultimo cerramos la conexion.

include("conexion.php");

function consulta($conn,$query){
	$resultado = mysqli_query($conn,$query);
	return $resultado;
}

$res = consulta($conn,"INSERT INTO servicios VALUES('','heidi','alpes suizos')");
var_dump($res);

mysqli_close($conn); //cierra la conexion

?>