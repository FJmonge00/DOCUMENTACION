<?php
$identificador= $_POST["identificador"];
$nombre= $_POST["nombre"];
$localidad= $_POST["localidad"];
include("conexion.php");

function consulta($conn,$query){
	$resultado = mysqli_query($conn,$query);
	return $resultado;
}

$res = consulta($conn,"UPDATE SERVICIO SET nombre='$nombre',servidor='$localidad' WHERE id='$identificador'");
var_dump($res);

mysqli_close($conn); //cierra la conexion

?>