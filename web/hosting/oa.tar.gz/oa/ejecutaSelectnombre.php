<?php
//Recogida de variables
$nombre= $_POST["nombre"];
include("conexion.php");

function consulta($conn,$query){
	$resultado = mysqli_query($conn,$query);
	return $resultado;
}

$res = consulta($conn,"SELECT * FROM SERVICIO WHERE nombre='$nombre'");
//var_dump($res);

mysqli_close($conn); //cierra la conexion

?>